var login = function() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
  
    if (username === 'admin' && password === 'admint') {
        document.querySelector('#myNavigator').pushPage('home.html', {data: {}});
    } else {
      ons.notification.alert('Incorrect username or password.');
    }
  };

  document.addEventListener('prechange', function(event) {
    document.querySelector('ons-toolbar .center')
      .innerHTML = event.tabItem.getAttribute('label');
  });

  // input data 
var input = function(){
    

  var data = {
    'nama' : document.getElementById('nama').value,
    'nim'  : document.getElementById('nim').value,
    'gender' : document.querySelector('ons-radio').value,
    'alamat' : document.getElementById('alamat').value
  };

  
      MyJsonData = JSON.stringify(data);
      localStorage.setItem('dataMhs', MyJsonData);
      ons.notification.alert('Data Berhasil Tersimpan Di Local Storage.');

}

// ambil data dari localstorage
var ambilData = function(){
//Retrieving data:
data = localStorage.getItem("dataMhs");
obj = JSON.parse(data);

var text = "";
var x;
for (x in obj) {
  text +=  '<ons-list-item modifier="longdivider" >'+ obj[x] + '</ons-list-item>';
}
document.getElementById("list-data-input").innerHTML = text;


}


var hideAlertDialog = function() {
document
  .getElementById('my-alert-dialog')
  .hide();
};

var notify = function() {
ons.notification.alert('This dialog was created with ons.notification');
};



var logout = function(e){
  document.querySelector('#myNavigator').pushPage('login.html')
  
};